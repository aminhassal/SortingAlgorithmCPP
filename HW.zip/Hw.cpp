﻿#include <iostream>
using namespace std;
//اضافة للبداية
void PushValueInFirst(int arr[], int value, int SizeOfArray) {
    for (int i = SizeOfArray; i >= 0; i--) {
        arr[i + 1] = arr[i];
    }
    arr[0] = value;
}
//اضافة للنهاية
void PushValueInLast(int arr[], int value, int SizeOfArray) {
    arr[SizeOfArray] = value;
}
//اضافة للوسط
void PushValueInMiddle(int arr[], int value, int SizeOfArray) {
    int middle = SizeOfArray / 2;

    // نقل العناصر بدءًا من الوسط إلى اليمين
    for (int i = SizeOfArray - 1; i >= middle; i--) {
        arr[i + 1] = arr[i];
    }

    arr[middle] = value;
}
//البحث الثنائي
int BinarySearch(int arr[], int left, int right, int target) {
    while (left <= right) {
        int mid = left + (right - left) / 2;

        // إذا كانت القيمة الموجودة في الموقع المتوسط تساوي القيمة المستهدفة، نعيد الموقع المتوسط
        if (arr[mid] == target) {
            return mid;
        }

        // إذا كانت القيمة الموجودة في الموقع المتوسط أكبر من القيمة المستهدفة، ننقل right للموقع المتوسط - 1
        else if (arr[mid] > target) {
            right = mid - 1;
        }

        // إذا كانت القيمة الموجودة في الموقع المتوسط أصغر من القيمة المستهدفة، ننقل left للموقع المتوسط + 1
        else {
            left = mid + 1;
        }
    }

    // إذا لم يتم العثور على القيمة المستهدفة، نعيد -1
    return -1;
}
//دالة العرض
void DisplayArray(int arr[], int SizeOfArray) {
    for (int i = 0; i < SizeOfArray + 1; i++) {
        cout << arr[i];
    }
}
//int main() {
//    int arr[] = { 2,3,4,5,6,7,8,9 };
//    int x = sizeof(arr);
//    cout << x;
//    //PushValueInFirst(arr, 1, 8);
//    //PushValueInLast(arr, 10, 9);
//    //DisplayArray(arr, 9);
//}