﻿//#include <iostream>
//using namespace std;
////اضافة للنهاية
//void PushValueInLast(int arr[], int value, int SizeOfArray) {
//    arr[SizeOfArray] = value;
//}
//دالة العرض
//void DisplayArray(int arr[], int SizeOfArray) {
//    for (int i = 0; i < SizeOfArray + 1; i++) {
//        cout << arr[i];
//    }
//}
//int main() {
//    int arr[] = { 2,3,4,5,6,7,8,9 };
//    PushValueInLast(arr, 10, 9);
//    DisplayArray(arr, 9);
//}