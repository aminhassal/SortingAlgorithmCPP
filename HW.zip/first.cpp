﻿//#include <iostream>
//using namespace std;
////اضافة للبداية
//void PushValueInFirst(int arr[], int value, int SizeOfArray) {
//    for (int i = SizeOfArray; i >= 0; i--) {
//        arr[i + 1] = arr[i];
//    }
//    arr[0] = value;
//}
////دالة العرض
//void DisplayArray(int arr[], int SizeOfArray) {
//    for (int i = 0; i < SizeOfArray + 1; i++) {
//        cout << arr[i];
//    }
//}
//int main() {
//    int arr[] = { 2,3,4,5,6,7,8,9 };
//    PushValueInFirst(arr, 1, 8);
//    DisplayArray(arr, 9);
//}