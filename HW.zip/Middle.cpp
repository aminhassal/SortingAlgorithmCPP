﻿//#include <iostream>
//using namespace std;
//
//void PushValueInMiddle(int arr[], int value, int SizeOfArray) {
//    int middle = SizeOfArray / 2;
//
//    // نقل العناصر بدءًا من الوسط إلى اليمين
//    for (int i = SizeOfArray - 1; i >= middle; i--) {
//        arr[i + 1] = arr[i];
//    }
//
//    arr[middle] = value;
//}

//int main() {
//    int arr[10] = { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10 };
//    int SizeOfArray = 10;
//    int value = 99;
//
//    cout << "Before adding value in the middle: ";
//    for (int i = 0; i < SizeOfArray; i++) {
//        cout << arr[i] << " ";
//    }
//
//    PushValueInMiddle(arr, value, SizeOfArray);
//    SizeOfArray++;
//
//    cout << "\nAfter adding value in the middle: ";
//    for (int i = 0; i < SizeOfArray; i++) {
//        cout << arr[i] << " ";
//    }
//}